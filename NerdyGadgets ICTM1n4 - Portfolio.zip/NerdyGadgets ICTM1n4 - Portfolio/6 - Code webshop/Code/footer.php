            </div> <!-- div subContent -->
        </div> <!-- div content -->
    </div> <!-- div achtergrond -->
    <div class="footer">
        <form method="post" action="customerService.php">
            <input type="submit" name="toCustomerService" value="Klantenservice" class="toCustomerServiceButton">
        </form>
    </div> <!-- div footer -->
</body>
</html>